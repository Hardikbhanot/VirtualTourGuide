import MapC from "./map";
import React from "react";
import "./App.css";

function App() {
  return (
    <>
      <MapC />
    </>
  );
}

export default App;
