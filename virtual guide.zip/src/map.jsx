import React, { useEffect } from "react";
import Map from "mapmyindia-react";

function MapC() {
  //   useEffect(() => {
  return (
    <Map
      style={{ height: "100vh", width: "100%" }}

      markers={[
        {
          position: [28.567396, 77.251571],
          draggable: true,
          title: "Marker title",
        //   icon: '',
          onClick: (e) => {
            console.log("clicked ");
          },
          onDragend: (e) => {
            console.log("dragged");
          },
        },

        {
          position: [28.5665214, 77.2509104], // [lat, lng]
          draggable: false, // true / false
          title: "", // string
          onClick: () => {}, // Marker click event listener
          onDragend: () => {}, // Marker drag-end event listener
        },
      ]}
    />
  );
  //   }, []);
}

export default MapC;
